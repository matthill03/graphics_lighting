#pragma once
#include <windows.h>
#include "Resource.h"
#include <string>
#include <exception>
#include "HelperFunctions.h"
