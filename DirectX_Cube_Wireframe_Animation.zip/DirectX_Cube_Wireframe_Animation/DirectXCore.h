#pragma once
#include <d3d11.h>
#include <d3dcompiler.h>
#include <DirectXMath.h>
#include <DirectXColors.h>
#include <wrl.h>

using namespace DirectX;

using Microsoft::WRL::ComPtr;

